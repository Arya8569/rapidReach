import requests

def geocode_address(parsed_data):
    """
    Implements the 7-Strategy Waterfall Geocoding Pipeline
    """
    attempts_log = []
    
    # Extract components from parsed data (which now includes AI-normalized components)
    # The 'parsed_data' dict is expected to be richer now.
    
    original_text = parsed_data.get('original', '')
    
    # Merged components from AI and Regex
    # We prefer the AI's 'components' if available, otherwise fallback to parser
    ai_comps = parsed_data.get('ai_components', {})
    
    # Priority Extraction
    landmark = ai_comps.get('landmark') or (parsed_data.get('landmarks')[0] if parsed_data.get('landmarks') else None)
    locality = ai_comps.get('locality')
    city = ai_comps.get('city') or (parsed_data.get('cities')[0] if parsed_data.get('cities') else None)
    corrected_address = ai_comps.get('corrected_address') or original_text
    
    # --- Strategy 1: Exact Landmark Match (Confidence: 1.0) ---
    if landmark and city:
        query = f"{landmark}, {city}"
        result = _call_nominatim(query)
        attempts_log.append({"stage": "Strategy 1: Exact Landmark", "query": query, "success": bool(result), "result": result})
        if result: return result, attempts_log

    # --- Strategy 2: Locality Match (Confidence: 0.9) ---
    if locality and city:
        query = f"{locality}, {city}"
        result = _call_nominatim(query)
        attempts_log.append({"stage": "Strategy 2: Locality", "query": query, "success": bool(result), "result": result})
        if result: return result, attempts_log
    
    # --- Strategy 3: City Fallback (Confidence: 0.5) ---
    if city:
        query = f"{city}"
        result = _call_nominatim(query)
        attempts_log.append({"stage": "Strategy 3: City Fallback", "query": query, "success": bool(result), "result": result})
        # Note: We usually don't return immediately on City fallback if we want to try for better accuracy?
        # But the prompt says "Once a strategy returns a result, we get a lat, lon". 
        # However, City fallback is low confidence. Maybe keep it as a baseline but let Drill-Downs override?
        # The prompt implies a waterfall where the FIRST success wins.
        # But City fallback is often too broad.
        # I will store it but optionally continue to Strategy 4 if this is just "Mumbai".
        # For strict compliance, I'll return it, but maybe check if Strategy 4 gives better score?
        # Let's follow strict waterfall: If this succeeds, return. 
        # But wait, Strategy 4 (Full Text) might be "Shivaji Park, Dadar" which is better than Strategy 3 "Mumbai".
        # The Prompt Order lists City Fallback as Strategy 3. This seems risky if Strategy 4 is "Full Text".
        # Actually, usually Full Text is tried earlier. 
        # Prompt says: "Strategy 3: City Fallback (Confidence: 0.5)".
        # "Strategy 4: Full Text Fallback (Confidence: 0.8)".
        # If I strictly follow 3 before 4, "Mumbai" will stop "Taj Mahal, Agra".
        # I will execute Strategy 4 BEFORE Strategy 3 based on logical confidence order provided in text (0.8 > 0.5).
        # Wait, the prompt lists them 1, 2, 3, 4. 
        # "The GeocodingService executes these strategies in order:"
        # 1. Landmark
        # 2. Locality
        # 3. City Fallback
        # 4. Full Text
        # That order implies City Fallback is prioritized? That seems like a doc bug or specific design for "safe" results.
        # However, looking at the user request "Strategy 3: Full Text Fallback" in the Mermaid Diagram...
        # The Mermaid says: H -- Fail --> I{Strategy 2: Locality} -- Fail --> J{Strategy 3: Full Text Fallback}
        # But the text list says "City Fallback" is 3. 
        # I will prioritize FULL TEXT (0.8) over CITY (0.5). I will swap 3 and 4 to ensure high confidence wins.
        pass # Defer return until after checking Full Text if needed, or strictly follow my intuition?
        # I will follow Confidence Scores. 
    
    # --- Strategy 4 (Moved up): Full Text Fallback (Confidence: 0.8) ---
    # Try the corrected address first, then original
    queries_to_try = []
    if corrected_address and corrected_address != original_text:
        queries_to_try.append(corrected_address)
    if original_text:
        queries_to_try.append(original_text)
        
    for query in queries_to_try:
        result = _call_nominatim(query)
        attempts_log.append({"stage": "Strategy 3/4: Full Text", "query": query, "success": bool(result), "result": result})
        if result: return result, attempts_log

    # Back to City Fallback (Confidence: 0.5) - now as backup
    if city and not any(l['success'] for l in attempts_log if 'City' in l['stage']): 
         # Only if we haven't found anything better
         query = city
         result = _call_nominatim(query)
         attempts_log.append({"stage": "Strategy: City Fallback", "query": query, "success": bool(result), "result": result})
         if result: return result, attempts_log

    # --- Strategy 5: Recursive Comma Drill-Down (Confidence: 0.7 - 0.1*i) ---
    parts = original_text.split(',')
    if len(parts) > 1:
        # Recursive remove first part
        # "Flat 5, Building A, Main Road, Mumbai" -> "Building A, Main Road, Mumbai"
        for i in range(1, len(parts)):
            sub_query = ",".join(parts[i:]).strip()
            if not sub_query: continue
            
            result = _call_nominatim(sub_query)
            attempts_log.append({"stage": f"Strategy 5: Comma Drill-Down L{i}", "query": sub_query, "success": bool(result), "result": result})
            if result: return result, attempts_log

    # --- Strategy 6: Recursive Word Drill-Down (Front) ---
    # "Near big tree vidyalankar wadala" -> remove "Near", "Near big"...
    words = original_text.split()
    if len(words) > 1:
        for i in range(1, min(len(words), 5)):
             sub_query = " ".join(words[i:]).strip()
             result = _call_nominatim(sub_query)
             attempts_log.append({"stage": f"Strategy 6: Word Drill-Down Front L{i}", "query": sub_query, "success": bool(result), "result": result})
             if result: return result, attempts_log

    # --- Strategy 7: Reverse Word Drill-Down (Back) ---
    # "Anushakti Nagar BARC colony" -> remove "colony"
    if len(words) > 1:
        for i in range(1, min(len(words), 3)): # Try removing last 1, 2, 3 words
             sub_query = " ".join(words[:-i]).strip()
             result = _call_nominatim(sub_query)
             attempts_log.append({"stage": f"Strategy 7: Word Drill-Down Back L{i}", "query": sub_query, "success": bool(result), "result": result})
             if result: return result, attempts_log

    return None, attempts_log

def _call_nominatim(query):
    url = "https://nominatim.openstreetmap.org/search"
    params = {
        "q": query,
        "format": "json",
        "limit": 1,
        "addressdetails": 1
    }
    headers = {
        "User-Agent": "SmartAddressIntelligence/1.0"
    }
    
    try:
        response = requests.get(url, params=params, headers=headers)
        if response.status_code == 200:
            data = response.json()
            if data:
                return {
                    "lat": data[0].get('lat'),
                    "lon": data[0].get('lon'),
                    "display_name": data[0].get('display_name'),
                    "confidence_score": 1.0 if "station" in query.lower() or "landmark" in query.lower() else 0.8
                }
    except Exception as e:
        print(f"Geocoding Error: {e}")
    
    return None

def reverse_geocode(lat, lon):
    url = "https://nominatim.openstreetmap.org/reverse"
    params = {
        "lat": lat,
        "lon": lon,
        "format": "json",
    }
    headers = {
        "User-Agent": "SmartAddressIntelligence/1.0"
    }
    try:
        response = requests.get(url, params=params, headers=headers)
        if response.status_code == 200:
            data = response.json()
            if data:
                return {
                    "lat": str(lat),
                    "lon": str(lon),
                    "display_name": data.get('display_name'),
                    "confidence_score": 1.0 
                }
    except Exception as e:
        print(f"Reverse Geocoding Error: {e}")
    return None
