from flask import Flask, request, jsonify
from flask_cors import CORS
from deep_translator import GoogleTranslator
import nltk
from address_parser import parse_address
from geocoding_service import geocode_address, reverse_geocode
from vision_service import vision_service
import os
import uuid

# ... (omitted)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/analyze-image', methods=['POST'])
def analyze_image():
    try:
        # Check if 'image' is in request files
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
            
        image_file = request.files['image']
        if image_file.filename == '':
            return jsonify({'error': 'No selected file'}), 400

        # Save temporarily
        temp_dir = "temp_uploads"
        os.makedirs(temp_dir, exist_ok=True)
        filename = f"{uuid.uuid4()}_{image_file.filename}"
        filepath = os.path.join(temp_dir, filename)
        image_file.save(filepath)

        print(f"=== PROCESSING IMAGE: {filename} ===")

        # Analyze
        analysis_result = vision_service.analyze_image(filepath)
        
        # Cleanup
        try:
            os.remove(filepath)
        except:
            pass
            
        final_result = {
            "source": analysis_result.get("source"), # 'gps_exif' or 'visual_ai'
            "description": analysis_result.get("description"),
            "location": None,
            "error": analysis_result.get("error")
        }

        # Resolution Strategy
        if final_result["source"] == "gps_exif":
            print("--- SOURCE: EXIF ---")
            # Precise GPS found -> Get Address
            lat = analysis_result["lat"]
            lon = analysis_result["lon"]
            address_info = reverse_geocode(lat, lon) # Returns {lat, lon, display_name...}
            final_result["location"] = address_info
            
        elif final_result["source"] == "visual_ai":
            print("--- SOURCE: VISUAL AI ---")
            description = final_result["description"]
            print(f"AI RAW DESCRIPTION: {description}")
            
            # Simple wrapper to match expected input for geocode_address
            # 1. Parse
            mock_parsed = parse_address(description)
            print(f"PARSED DATA: {mock_parsed}")
            
            # 2. Geocode
            geocoded, logs = geocode_address(mock_parsed)
            print(f"GEOCODE RESULT: {geocoded}")
            
            # 3. Fallback: Raw Search if Geocoding Failed and Description exists
            if not geocoded and description:
                print("Geocoding failed. Trying raw fallback search...")
                from geocoding_service import _call_nominatim
                # Try searching the raw description (sanitized)
                # Take first line or reasonable length
                raw_query = description.split('\n')[0].strip()
                if len(raw_query) > 100: raw_query = raw_query[:100]
                
                print(f"Attempting Raw Query: {raw_query}")
                raw_result = _call_nominatim(raw_query)
                if raw_result:
                    print(f"Raw fallback success! {raw_result}")
                    geocoded = raw_result
                else:
                     print("Raw fallback failed.")
            
            final_result["location"] = geocoded
            
        return jsonify(final_result)

    except Exception as e:
        print(f"Image analysis error: {e}")
        return jsonify({'error': str(e)}), 500

# Download necessary NLTK data
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('chunkers/maxent_ne_chunker')
    nltk.data.find('taggers/averaged_perceptron_tagger')
    nltk.data.find('corpora/words')
except LookupError:
    print("Downloading NLTK data...")
    nltk.download('punkt')
    nltk.download('maxent_ne_chunker')
    nltk.download('averaged_perceptron_tagger')
    nltk.download('words')
    nltk.download('punkt_tab')
    nltk.download('averaged_perceptron_tagger_eng')
    nltk.download('maxent_ne_chunker_tab')

@app.route('/analyze', methods=['POST'])
def analyze_address():
    try:
        data = request.json
        original_text = data.get('address', '')
        
        if not original_text:
            return jsonify({'error': 'No address provided'}), 400

        print(f"=== PROCESSING: {original_text} ===")

        # 1. Translation Layer
        try:
            translated_text = GoogleTranslator(source='auto', target='en').translate(original_text)
            print(f"Translated: {translated_text}")
        except Exception as e:
            print(f"Translation failed: {e}")
            translated_text = original_text

        # 2. AI Normalization Layer (New Step 1 from Pipeline)
        from ai_address_service import ai_address_service
        ai_result = ai_address_service.normalize_address(translated_text)
        print(f"AI Result: {ai_result}")

        # 3. Parsing Layer
        # Parse the *corrected* address if available, or just parse original to get base entities
        # We pass both to the geocoder via the combined dict
        parsing_result = parse_address(translated_text)
        
        # Merge AI components
        if ai_result:
             parsing_result['ai_components'] = ai_result.get('components', {})
             parsing_result['ai_corrected_address'] = ai_result.get('corrected_address')
             # Also update 'original' for fallbacks if correction is better? 
             # No, keep original as original.
        print(f"Combined Parsing Result: {parsing_result}")

        # 4. Geocoding Layer (7-Strategy Waterfall)
        geocoding_result, attempts_log = geocode_address(parsing_result)
        print(f"Geocoding Result: {geocoding_result}")

        response = {
            'original_text': original_text,
            'translated_text': translated_text,
            'parsing_result': parsing_result,
            'geocoding_result': geocoding_result,
            'attempts_log': attempts_log
        }

        return jsonify(response)

    except Exception as e:
        print(f"Error processing request: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/translate', methods=['POST'])
def translate_text():
    try:
        data = request.json
        text = data.get('text', '')
        target_lang = data.get('target_lang', 'en')
        
        if not text:
            return jsonify({'translated_text': ''})
            
        # Map simple codes to deep_translator codes if needed
        # deep_translator uses standard codes: 'hi', 'mr', 'en'
        
        translated = GoogleTranslator(source='auto', target=target_lang).translate(text)
        return jsonify({'translated_text': translated})
    except Exception as e:
        print(f"Translation error: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
